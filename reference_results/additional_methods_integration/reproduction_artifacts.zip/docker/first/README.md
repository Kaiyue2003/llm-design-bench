# Seeded Publication Benchmark

Normalized maximum score (100th percentile of K=8 recommendations), reported as mean +/- sample SD across 1 independent seeds. Higher is better.

| Method | Ackley | Booth | Mean rank | Median rank |
| --- | ---: | ---: | ---: | ---: |
| D(best) | 1.000 +/- 0.000 | 1.000 +/- 0.000 | -- | -- |
| Best Logged | 1.000 +/- 0.000 | 1.000 +/- 0.000 | 4.00 | 4.00 |
| COM | 0.905 +/- 0.000 | **1.001 +/- 0.000** | 3.50 | 3.50 |
| BDI | 0.613 +/- 0.000 | 1.000 +/- 0.000 | 5.50 | 5.50 |
| Offline MLP | 0.905 +/- 0.000 | <u>1.001 +/- 0.000</u> | 3.50 | 3.50 |
| CbAS | 0.265 +/- 0.000 | 0.993 +/- 0.000 | 7.50 | 7.50 |
| MINs | 0.874 +/- 0.000 | 0.936 +/- 0.000 | 8.50 | 8.50 |
| DDOM | 0.103 +/- 0.000 | 0.868 +/- 0.000 | 13.00 | 13.00 |
| GABO | 1.069 +/- 0.000 | 0.940 +/- 0.000 | 6.00 | 6.00 |
| GTG | 0.118 +/- 0.000 | 0.869 +/- 0.000 | 11.50 | 11.50 |
| RGD | 0.037 +/- 0.000 | 0.869 +/- 0.000 | 13.00 | 13.00 |
| BONET | 0.317 +/- 0.000 | 0.976 +/- 0.000 | 8.50 | 8.50 |
| DEMO | <u>1.209 +/- 0.000</u> | 0.981 +/- 0.000 | 4.50 | 4.50 |
| ROOT | 0.185 +/- 0.000 | 0.730 +/- 0.000 | 12.50 | 12.50 |
| SPADE | **1.249 +/- 0.000** | 0.991 +/- 0.000 | 3.50 | 3.50 |

Bold is best and underlining is second best within each task, based on the mean score.

## Experiment Contract

- Seeds: `38`. The synthetic logged-dataset seed and optimizer seed both equal the trial seed.
- Data-mixture logged observations are fixed upstream data; only the optimizer seed varies by trial.
- Score: `(generated best utility - full logged minimum utility) / (full logged maximum utility - full logged minimum utility)`. Scores above 1 are allowed.
- Data-mixture training visibility: utility percentiles [0, 40].
- `D(best)` is the best optimizer-visible logged utility. LLM-DM logged runs retain their recorded model scale and training step, while method recommendations are evaluated at the target 1B/19,500-step fidelity.
- Synthetic functions: `ackley, booth`.
- Displayed uncertainty: sample SD.
- `task_summary.csv` also records sample SD, standard error, 95% Student-t CI, and observed seed range.
- Candidate count: `K=8` for every method and trial.

## Selection And Method Provenance

Explicit caller-selected synthetic tasks; no claim of an unbiased all-task comparison.

Additional methods are continuous PyTorch adaptations. Published-result parity is not established. Exact source revisions, settings and substitutions are in METHOD_PROVENANCE.md and run_metadata.json.

COM is a native PyTorch reimplementation of the conservative objective-model structure from [design-baselines](https://github.com/brandontrabucco/design-baselines).
BDI is the repository's native PyTorch/RBF-kernel adaptation of the forward/backward distillation structure in the [official BDI repository](https://github.com/GGchen1997/BDI). It does not claim numerical equivalence to the original JAX/Neural Tangents implementation.

## Reproduction Files

- [Raw per-seed runs](raw_runs.csv)
- [Aggregated task summary](task_summary.csv)
- [Rank summary](rank_summary.csv)
- [Seed manifest](seed_manifest.csv)
- [Run metadata](run_metadata.json)
- [Overleaf table](seeded_benchmark_table.tex)
- [Table 1-style mean +/- SE report](TABLE1_STYLE.md)
- [Table 1-style Overleaf table](seeded_benchmark_table_se.tex)
